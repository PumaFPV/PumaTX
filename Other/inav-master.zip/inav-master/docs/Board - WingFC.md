# Board - Wing FC

This FC can be bought here: https://inavflight.com/shop/s/bg/1318626

This board use the STM32F405RGT6 microcontroller and have the following features:
* 1024K bytes of flash memory,192K bytes RAM,168 MHz CPU/210 DMIPS

* The 16M byte SPI flash for data logging
* USB VCP and boot select button on board(for DFU)
* Current sensor
* Supports I2C device (shared with UART1)
* PPM input (UART3 RX)
