---
name: "\U0001F680Feature request"
about: Suggest a new feature for INAV
title: ''
labels: ''
assignees: ''

---

## Current Behavior
<!-- A clear and concise description of what is the current behavior / usecase.  -->

## Desired Behavior
<!-- A clear and concise description of what you want to happen.  -->

## Suggested Solution
<!-- Suggest a solution that the community/maintainers/you may take to enable the desired behavior  -->
<!-- NOTE: Feature Requests without suggested solutions may not be addressed with the same level of urgency as those that have suggested solutions -->

## Who does this impact? Who is this for?
<!-- Who is this for? All users? Airplane users? Beginners? Advanced? Yourself? People using X, Y, Z, etc.? -->

## Additional context
<!-- Add any other context or links about the feature request here. -->
