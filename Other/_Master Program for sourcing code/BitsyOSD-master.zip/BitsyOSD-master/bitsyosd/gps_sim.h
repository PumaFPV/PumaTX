/**
   ___  _ __           ____  _______ 
  / _ )(_) /____ __ __/ __ \/ __/ _ \
 / _  / / __(_-</ // / /_/ /\ \/ // /
/____/_/\__/___/\_, /\____/___/____/ 
               /___/                 

GPS Simulated Parser

Great for development!                                         

**/

#ifndef GPS_P_H
#define GPS_P_H

#endif

