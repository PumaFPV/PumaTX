Import("env")
env.Replace(PROGNAME="backpack")
