# ESP8266SerialToWebsocket
Stream serial messages to a hosted websocket on the ESP8266
