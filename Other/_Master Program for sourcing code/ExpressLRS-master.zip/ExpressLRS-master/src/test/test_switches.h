// Declare the entry point provided by test_switches

void setup_switches(void);