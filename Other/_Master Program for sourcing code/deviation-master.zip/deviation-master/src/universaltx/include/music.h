#include "../../music.h"
#define MUSIC_Play(x)
#define MUSIC_Beep(w,x,y,z)

