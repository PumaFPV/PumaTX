#define _GUI_CreateMappedItem_Helper(x)  (void)1
#define _GUI_DrawMappedStart()           (void)1
#define _GUI_DrawMappedStop()            (void)1
#define _GUI_UnmapWindow(x)              (void)1
#define _GUI_ClearMappedBox(box, color) LCD_FillRect(box->x, box->y, box->width, box->height, color)
