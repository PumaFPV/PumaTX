const char* CONFIG_VoiceParse();
