#ifndef _MUSICCONFIG_PAGE_H_
#define _MUSICCONFIG_PAGE_H_
#include "config/voice.h"

#if HAS_MUSIC_CONFIG
struct voiceconfig_page {
};
#endif
#endif
