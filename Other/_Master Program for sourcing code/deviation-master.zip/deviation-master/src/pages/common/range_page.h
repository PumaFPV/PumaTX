#ifndef _RANGE_PAGE_H_
#define _RANGE_PAGE_H_

struct range_page {
    int testing;
    enum TxPower old_power;
};
#endif
