#ifndef _TELEMCONFIG_PAGE_H_
#define _TELEMCONFIG_PAGE_H_
#include "telemetry.h"
struct telemconfig_page {
};
#endif
