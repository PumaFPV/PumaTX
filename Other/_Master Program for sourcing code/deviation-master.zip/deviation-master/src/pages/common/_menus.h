#ifndef _MENUS_H__
#define _MENUS_H__

struct menu_page {
    unsigned menu_id;
};

#endif /* MENUS_H_ */
