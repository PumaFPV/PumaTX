#ifndef _TOGGLE_SELECT_H_
#define _TOGGLE_SELECT_H_
struct toggle_select_page {
    u8 tglicons[3];
    u8 tglidx;
};
#endif
