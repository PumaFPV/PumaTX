#ifndef _CRSFDEVICE_PAGE_H_
#define _CRSFDEVICE_PAGE_H_

#if SUPPORT_CRSF_CONFIG
#include "crsf.h"

struct crsfdevice_page {
    char strings[CRSF_MAX_STRING_BYTES];
};

#endif
#endif
