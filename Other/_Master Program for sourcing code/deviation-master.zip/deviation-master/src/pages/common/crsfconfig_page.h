#ifndef _CRSFCONFIG_PAGE_H_
#define _CRSFCONFIG_PAGE_H_

#if SUPPORT_CRSF_CONFIG
struct crsfconfig_page {
    u32 last_update;
};

#endif
#endif
