#ifndef _ICONS_H_
#define _ICONS_H_

enum Icons {
    ICON_EXIT,
    ICON_OPTIONS,
    ICON_PREVPAGE,
    ICON_NEXTPAGE,
    ICON_CHANTEST,
    ICON_MODELICO,
    ICON_ORDER,
    ICON_LAYOUT_ADD,
    ICON_LAYOUT_CFG,
    ICON_LAST,
};

extern const struct ImageMap icons[ICON_LAST];

#endif
