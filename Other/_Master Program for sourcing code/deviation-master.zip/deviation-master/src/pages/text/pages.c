
#include "common.h"
#include "pages.h"
#include "gui/gui.h"
#include "../128x64x1/pages.c"

struct _gui_objs gui_objs;
