#ifndef _PAGES_H_
#include "lcd_page_props.h"
#include "../common/_pages.h"
#include "guiobj.h"
#include "../128x64x1/pages.h"
#endif
