# Moved
The class supporting the WS2812 pixels has moved to the `cpp_utils` folder.

See also:
* Github: [MartyMacGyver/ESP32-Digital-RGB-LED-Drivers](https://github.com/MartyMacGyver/ESP32-Digital-RGB-LED-Drivers)
* Github: [FozzTexx/ws2812-demo](https://github.com/FozzTexx/ws2812-demo)