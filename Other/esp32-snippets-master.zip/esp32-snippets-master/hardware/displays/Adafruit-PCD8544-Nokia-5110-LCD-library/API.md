* begin
```
begin(contrast, bias)
```
The defaults are:
* `contrast`: 40
* `bias`: 4

* clearDisplay
Clear the existing content of the screen.
```
clearDisplay()
```

* display
Synchronize what we want to display to the LCD.
```
display()
```

* setContrast
```
setContrast(val)
```