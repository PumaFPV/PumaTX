#Real time clock
This is an example of connecting a real time clock to the ESP32.