# C++ Skeletons
This directory contains some skeletons for main files for C++ applications.

* `main_helloworld.cpp` - Simple main startup.
* `main_network.cpp` - Simple main with networking via WiFi.