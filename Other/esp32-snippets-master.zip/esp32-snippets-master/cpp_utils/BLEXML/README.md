# XML to JSON
The BLE authority makes available description of Services and Characteristics in XML documents.  Our goal is to work with these
in JavaScript. These tools download each of the XML documents and convert them to JSON equivalents.  To perform that task we
use the NPM package called [xml2json-cli](https://www.npmjs.com/package/xml2json-cli).