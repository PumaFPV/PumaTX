# ESP32 Snippets
This repository hosts a set of ESP32 snippets that are in different
stages of completeness.  They are made available in the hope that there
may be something of value to you and under the notion that something
is better than nothing.  The samples are being categorized.

* vfs - Virtual File System
* wifi - WiFi access
* curl - Examples of curl usage
