#I2CScanner
Using the Arduino Wire class, execute an I2C scan across all the devices and see
which ones respond.  This is a poor mans version of an `i2cdetect` like tool.