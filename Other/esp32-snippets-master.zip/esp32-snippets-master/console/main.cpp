extern "C" {
	void app_main(void);
}

extern void test_linenoise();
extern void test_argtable();
extern void test_console();

void app_main(void)
{
	//test_linenoise();
	//test_argtable();
	test_console();
}
