### See also
* hardware/neopixels
* hardware/infrared